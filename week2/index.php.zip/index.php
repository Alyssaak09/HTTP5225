<!DOCTYPE html>
<html lang="">
<head>
    <title>Week 2</title>
</head>
<body>

   <!-- Learning how to use echo in php -->

   <?php


     echo "<h1>Hello World </h1>";
     $firstname = "Alyssa";
     $lastname = "Austin";
     $program = "Web Development"
     echo "$lastname  $firstname  $program";
     ?>
    
</body>
</html>